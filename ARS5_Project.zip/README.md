# Quadcopter Backstepping Control

This project is a part of the ARS5 course in UTC.

# Authors

- Stefano MUSSO PIANTELLI
- Elias Charbel SALAMEH

# Date

Thursday 15 January 2026


# Instruction to run the code

The following files are function to compute the the desired trajecotry function and its derivatives:
  - trajectory_point.m;
  - trajectory_cylindral.m
  - trajectory_lemniscate.m
  - trajectory_spiral.m
  
In order to run a simulation it is necessary comment out the desire trajectory and comment others from lines 27 to 31 in the file named main.m
Additonaly, you can follow the same procedure to simulate the Multi-Agent control in the file named multi_main.m
